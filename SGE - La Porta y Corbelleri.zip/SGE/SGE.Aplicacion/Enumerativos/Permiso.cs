namespace SGE.Aplicacion;

// Definición de la enumeración para los tipos de permisos
public enum Permiso
{
    ExpedienteAlta,
    ExpedienteBaja,
    ExpedienteModificacion,
    TramiteAlta,
    TramiteBaja,
    TramiteModificacion
}
